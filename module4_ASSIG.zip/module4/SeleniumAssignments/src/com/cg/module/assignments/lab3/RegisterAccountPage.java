package com.cg.module.assignments.lab3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class RegisterAccountPage {
	
	public static String driverpath = "H:\\AJAYKUMAR\\SOFTWARES\\SELENIUM\\";
	

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//1.Enter URL
		driver.get("https://demo.opencart.com");
		
		//2.Verify Title:
		String actual_title = driver.getTitle();
		String expected_title = "Your Store";
		boolean title=actual_title.equals(expected_title);
		if(title)
		{
			System.out.println("Title Verified");
		}
		else 
		{
			System.out.println("Title did not match");
		}
		
		//3.Click on 'My Account'
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
		
		//4.Select 'Register' from dropdown
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
		
		//5.Verify the heading �Register Account�:
		boolean heading = driver.findElement(By.xpath("//*[@id='content']/h1")).isDisplayed();
		if(heading)
		{
			System.out.println("Heading Verified");
		}
		else 
		{
			System.out.println("Heading did not match");
		}
		
		//6.Click on 'Continue' button 
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		
		
		//7.Verify warning message 'Warning: You must agree to the Privacy Policy!'.
		String str =driver.findElement(By.xpath("//*[@id='account-register']/div[1]")).getText();
		boolean mesg=str.equals("Warning: You must agree to the Privacy Policy!");
		if(mesg)
		{
			System.out.println("Warning message Verified");
		}
		else 
		{
			System.out.println("Warning message did not match");
		}
		
		driver.close();
				
	
	}

}
