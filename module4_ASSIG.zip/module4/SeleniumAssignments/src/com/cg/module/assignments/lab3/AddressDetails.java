package com.cg.module.assignments.lab3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddressDetails {
	
public static String driverpath = "H:\\AJAYKUMAR\\SOFTWARES\\SELENIUM\\";
	

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//Enter URL
		driver.get("https://demo.opencart.com");
				
		//Click on 'My Account'
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
				
		//Select 'Register' from dropdown
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
				
		//Enter data in first name
		driver.findElement(By.name("firstname")).sendKeys("Ajaykumar");
		
		//Enter data in last name
		driver.findElement(By.name("lastname")).sendKeys("Yadav");
		
		//Enter valid 'E-mail':
		driver.findElement(By.id("input-email")).sendKeys("ajaykumar.yadav7028@capgemini.com");

						
		//Enter 'Telephone' which must be between 3 and 32 characters:
		driver.findElement(By.id("input-telephone")).sendKeys("7021919707");
		
		//Enter 'Password' which must be between 4 and 20 characters.
		driver.findElement(By.name("password")).sendKeys("ajaykumar");
		
		//Enter 'Password Confirm'.
		driver.findElement(By.name("confirm")).sendKeys("ajaykumar");
		
		//Click on 'Yes' Radio button
		driver.findElement(By.name("newsletter")).click();
		
		//Click on checkbox for 'I have read and agree to the Privacy Policy'.
		
		driver.findElement(By.name("agree")).click();
		
		
		//Click on 'Continue' button
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a")).click();
		
		//Enter data Email
		//driver.findElement(By.id("input-email")).sendKeys("ajaykumar.yadav3@capgemini.com");
		
		//Enter password
		//Enter data Email
		//driver.findElement(By.id("input-password")).sendKeys("ajaykumar");
		
		//Click on Login button
		//driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input[1]")).click();
				
		
		//Click on Address Book.
		driver.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[4]")).click();
		
		//Click on New Address.
		driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();
				
		driver.findElement(By.xpath("//*[@id=\'input-firstname\']")).sendKeys("Ajakumar");
		driver.findElement(By.xpath("//*[@id=\'input-lastname\']")).sendKeys("Yadav");
		driver.findElement(By.id("input-company")).sendKeys("Capgemini");
		driver.findElement(By.id("input-address-1")).sendKeys("b-425,saikrupa chs");
		driver.findElement(By.id("input-address-2")).sendKeys("near jupiter hospital,road no 1");
		driver.findElement(By.id("input-city")).sendKeys("Thane");
		driver.findElement(By.id("input-postcode")).sendKeys("400601");
		driver.findElement(By.xpath("//*[@id=\"input-country\"]/option[99]")).click();
		driver.findElement(By.xpath("//*[@id=\"input-zone\"]/option[20]")).click();
		driver.findElement(By.name("default")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div[2]/input")).click();
					
				
								
	//	driver.close();
	}
						


}

