package com.cg.module.assignments.lab3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Newsletter {public static String driverpath = "H:\\AJAYKUMAR\\SOFTWARES\\SELENIUM\\";


public static void main(String[] args) throws Exception {
	
	System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	//Enter URL
	driver.get("https://demo.opencart.com");
			
	//Click on 'My Account'
	driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
			
	//Select 'Register' from dropdown
	driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
			
	//Enter data in first name
	driver.findElement(By.name("firstname")).sendKeys("Ajaykumar");
	
	//Enter data in last name
	driver.findElement(By.name("lastname")).sendKeys("Yadav");
	
	//Enter valid 'E-mail':
	driver.findElement(By.id("input-email")).sendKeys("ajaykumar.yadav10@capgemini.com");

					
	//Enter 'Telephone' which must be between 3 and 32 characters:
	driver.findElement(By.id("input-telephone")).sendKeys("7021919707");
	
	//Enter 'Password' which must be between 4 and 20 characters.
	driver.findElement(By.name("password")).sendKeys("ajaykumar");
	
	//Enter 'Password Confirm'.
	driver.findElement(By.name("confirm")).sendKeys("ajaykumar");
	
	//Click on 'Yes' Radio button
	driver.findElement(By.name("newsletter")).click();
	
	//Click on checkbox for 'I have read and agree to the Privacy Policy'.
	
	driver.findElement(By.name("agree")).click();
	
	
	//Click on 'Continue' button
	driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
	
	String str =driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).getText();
	boolean mesg=str.equals("Your Account Has Been Created!");
	if(mesg)
	{
		System.out.println("Message Verified");
	}
	else 
	{
		System.out.println("Message did not match");
	}
		
	driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a")).click();
	
	//click on view orders
	driver.findElement(By.xpath("//*[@id=\"content\"]/ul[2]/li[1]/a")).click();
	

	
}

}
