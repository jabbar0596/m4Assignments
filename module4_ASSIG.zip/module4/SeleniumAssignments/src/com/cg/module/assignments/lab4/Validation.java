package com.cg.module.assignments.lab4;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Validation {
	
public static String driverpath = "H:\\AJAYKUMAR\\SOFTWARES\\SELENIUM\\";
	

	public static void main(String[] args) {
		
			System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
			WebDriver driver = new ChromeDriver();
		
			//1.Enter URL
			driver.get("https://demo.opencart.com");
		

			//Click on 'My Account'
			driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
					
			//Select 'Login' from dropdown
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
			
	
	
			//Enter data Email
			driver.findElement(By.id("input-email")).sendKeys("ajaykumar.yadav2@capgemini.com");
			
			//Enter password
			driver.findElement(By.id("input-password")).sendKeys("ajaykumar");
			
			//Click on Login button
			driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input[1]")).click();
			
			//Click component
			driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/a")).click();
			
			//Click monitors
			driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
			
			//Select 25 from 'Show' dropdown
			driver.findElement(By.xpath("//*[@id=\"input-limit\"]/option[2]")).click();
			
			//Click on add to cart
			driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
			
			//Click on specification tab
	//		driver.findElement(By.xpath("//*[@id=\'content\']/div[1]/div[1]/ul[2]/li[2]/a")).click();
			driver.findElement(By.linkText("Specification")).click();


			
}
}