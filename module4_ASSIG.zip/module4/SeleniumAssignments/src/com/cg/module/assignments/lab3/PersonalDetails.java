package com.cg.module.assignments.lab3;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PersonalDetails {

public static String driverpath = "H:\\AJAYKUMAR\\SOFTWARES\\SELENIUM\\";
	

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//Enter URL
		driver.get("https://demo.opencart.com");
				
		//Click on 'My Account'
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
				
		//Select 'Register' from dropdown
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
				
		//Enter data in first name
		driver.findElement(By.name("firstname")).sendKeys("Ajayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		String strfirst =driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div")).getText();
		boolean mesgfirst=strfirst.equals("First Name must be between 1 and 32 characters!");
		if(mesgfirst)
		{
			System.out.println("First name error message verified");
		}
		else 
		{
			System.out.println("First name error message did not verify");
		}
		
		driver.findElement(By.name("firstname")).clear();
		driver.findElement(By.name("firstname")).sendKeys("Ajaykumar");
		
		//Enter data in last name
		driver.findElement(By.name("lastname")).sendKeys("Yadavvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		String strlast =driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[3]/div/div")).getText();
		boolean mesglast=strlast.equals("Last Name must be between 1 and 32 characters!");
		if(mesglast)
		{
			System.out.println("Last name error message verified");
		}
		else 
		{
			System.out.println("Last name error message did not verify");
		}
		
		driver.findElement(By.name("lastname")).clear();
		driver.findElement(By.name("lastname")).sendKeys("Yadav");
		
		//Enter valid 'E-mail':
		driver.findElement(By.id("input-email")).sendKeys("ajaykumar.yadav@capgemini.com");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		
						
		//Enter 'Telephone' which must be between 3 and 32 characters:
		driver.findElement(By.id("input-telephone")).sendKeys("7021919707");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
				
	
				
								
	//	driver.close();
						

		
		

	}

}
