package com.cg.M4.lab3;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class OpenCartVerify {
	
	public static void main(String[] args) throws InterruptedException {
		
//		Part 1: Launch Application
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();

//		1. Launch the URL on Chrome
		driver.navigate().to("http://demo.opencart.com/");
		Thread.sleep(2000);
		
//		  2. Verify 'Title' of the page
		  if(driver.getTitle().contains("Your Store"))
		  {
		      System.out.println("Title Test Case Passed");	  
		  }
		  else
		  {
			  System.out.println("Title Test Case Failed");
		  }

//		  3. Click on 'My Account' dropdown
		  driver.findElement(By.xpath("//i[@class='fa fa-user']")).click();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
//		  4. Select 'Register' from dropdown		  
//		  WebElement wb1 = driver.findElement(By.xpath("//i[@class='fa fa-user']"));
//		  Select sel = new Select(wb1);
		  driver.findElement(By.linkText("Register")).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
//		  5. �Register Account� page will open up, verify the heading �Register Account�

		  WebElement wb1 = driver.findElement(By.xpath("//div[@id='content']/h1"));
		  
		  System.out.println(wb1.getText());
		  
		  if(wb1.getText().contains("Register Account"))
		  {
		      System.out.println("table title Case Passed");	  
		  }
		  else
		  {
			  System.out.println("table title Failed");
		  }
		  
//		  6. Click on 'Continue' button at the bottom of the page
		  driver.findElement(By.xpath("//input[@value='Continue']")).click();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
		  
		  
//		  7. Verify warning message 'Warning: You must agree to the Privacy Policy!'
 		  WebElement wb2 = driver.findElement(By.xpath("//*[@id='account-register']/div[1]"));
//		  System.out.println(wb2.getText());
          
		  boolean txt = driver.getPageSource().contains("Warning: You must agree to the Privacy Policy!");
//		  System.out.println(txt);

		  if(txt)
		  {
		      if(wb2.getText().contains("Warning: You must agree to the Privacy Policy!"))
		      {
		          System.out.println("Warning message Passed");	  
		      }
		      else
		      {
		    	  System.out.println("Warning message Failed");
	    	  }
		  }
		  
		//FirstName verification
		    
		    driver.findElement(By.name("firstname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdeghi");
		    driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
	        String txt5 = wbt3.getText();
	        String text6 = "First Name must be between 1 and 32 characters!";
	        if(text6.equals(txt5))
	        {
	        	System.out.println("First name error message verified");
	        	
	        }
	        else
	        {
	        	System.out.println("First name not verified");
	        }
		    
	        // Positive First name
	        driver.findElement(By.name("firstname")).clear();
	        driver.findElement(By.name("firstname")).sendKeys("Raj");
	        
	        
	        // LastName verification
	        driver.findElement(By.name("lastname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdeghi");
		    driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    
		    WebElement wbt2 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
	        String txt3 = wbt2.getText();
	        
	        String text4 = "Last Name must be between 1 and 32 characters!";
	        if(text4.equals(txt3))
	        {
	        	System.out.println("Last name error message verified");
	        	
	        }
	        else
	        {
	        	System.out.println("Last name not verified");
	        }
			// Positive Last name
	        driver.findElement(By.name("lastname")).clear();
	        driver.findElement(By.name("lastname")).sendKeys("Subash");
	        
	        //Email and telephone
	        driver.findElement(By.id("input-email")).sendKeys("jabbar6@gmail.com");
	        driver.findElement(By.id("input-telephone")).sendKeys("04226541441");
	        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        
	        //Password
	        driver.findElement(By.name("password")).sendKeys("rajsubash");
	        driver.findElement(By.id("input-confirm")).sendKeys("rajsubash");
	        
	        
	        //Radio Button
	        driver.findElement(By.name("newsletter")).click();
	        
	        //Privacy policy
	        driver.findElement(By.name("agree")).click();
	        
	        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        
	        //Account message Verification 
	        WebElement wb4 = driver.findElement(By.xpath("//*[@id='content']/h1"));
	        String Accmessage = wb4.getText();
	        String Vermessage ="Your Account Has Been Created!";
	        if(Vermessage.equals(Accmessage))
	        {
	        	System.out.println("Account Message has verified Successfully");
	        }
	        else
	        {
	        	System.out.println("Account Message not verified");
	        }
	        //clicking Continue
	        driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
	        //Address
	        driver.findElement(By.xpath("//*[@id='column-right']/div/a[4]")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        //FirstName add       
	        driver.findElement(By.id("input-firstname")).sendKeys("Raj");
	        //LastName add
	        driver.findElement(By.id("input-lastname")).sendKeys("Raj");
	        //CompanyName   add
	        driver.findElement(By.id("input-company")).sendKeys("Capgemini");
	        //Address
	        driver.findElement(By.id("input-address-1")).sendKeys("52,Balasundaram street,Avarampalayam,Coimbatore");
	        //City add
	        driver.findElement(By.id("input-city")).sendKeys("Bangalore");
	        //Post code add
	        driver.findElement(By.id("input-postcode")).sendKeys("641006");
	        //Country name
	        WebElement wb11 = driver.findElement(By.id("input-country"));
	        Select sel = new Select(wb11);
	        sel.selectByValue("222");
	        Thread.sleep(3000);
	        //Region and Zone
	        WebElement wb22 = driver.findElement(By.id("input-zone"));
	        Select sel1 = new Select(wb22);
	        sel1.selectByValue("3525");
	        
	        driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        
            driver.close();
		  
			
	}



}
