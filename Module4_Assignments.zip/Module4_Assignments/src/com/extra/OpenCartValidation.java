package extra;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;


public class OpenCartValidation {
   
	static String driverpath="C:\\Users\\jabmoham\\Documents\\zip files\\VnVATParticipantsMaterial\\VNV Software\\Selenium\\";
//	static String driverpath = "C:\\Users\\jabmoham\\Documents\\zip files\\VnVATParticipantsMaterial\\VNV Software\\Selenium\\";

	public static void main(String[] args) throws InterruptedException {
		
//		Part 1: Launch Application
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
//		WebDriver driver=new HtmlUnitDriver();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();

//		Launch the URL on Chrome
		driver.navigate().to("https://demo.opencart.com/index.php?route=account/register");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
//		  Automate and validate the different sections of �Register Account� page:
//			  Part 2: For 'Your Personal Details'

        
//    	1. Enter data in 'First Name' text box
	    
        driver.findElement(By.name("firstname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdegh");
	    String firstName = driver.findElement(By.name("firstname")).getAttribute("value");
	    System.out.println("Length of first name :"+firstName.length());
	    
//    	2. Verify if 33 characters can be entered in 'First Name' text box by clicking
//    	on 'Continue' button.
//    	3. If not, verify error message.

        driver.findElement(By.xpath("//input[@value='Continue']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));

	    System.out.println(wbt3.getText());
        String firstNameError = "First Name must be between 1 and 32 characters!";
        
     
		  
        
		boolean flag = driver.getPageSource().contains(firstNameError);
		System.out.println(flag);

		  if(flag && firstName.length()>32)
		  {
		      if(wbt3.getText().contains(firstNameError))
		      {
		          System.out.println("First Name Error message Passed");	  
		      }
		      else
		      {
		    	  System.out.println("First Name Error message Failed");
				  // Positive First name
		          driver.findElement(By.name("firstname")).clear();
		          driver.findElement(By.name("firstname")).sendKeys("Raj");
	    	  }
		  }


//    	4. Enter data in 'Last Name' text box
        driver.findElement(By.name("lastname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdeghij");
	    String lastName = driver.findElement(By.name("lastname")).getAttribute("value");
	    System.out.println("Length of last name :"+lastName.length());

        driver.findElement(By.xpath("//input[@value='Continue']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        WebElement wbt4 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
	                                                   
	    System.out.println(wbt4.getText());
        String lastNameError = "Last Name must be between 1 and 32 characters!";
        


//    	5. Verify if 33 characters can be entered in 'First Name' text box by clicking
//    	on 'Continue' button.
//    	6. If not, verify error message.
        flag = driver.getPageSource().contains(lastNameError);
		System.out.println(flag);

		  if(flag && lastName.length()>32)
		  {
		      if(wbt4.getText().contains(lastNameError))
		      {
		          System.out.println("last Name Error message Passed");	  
		      }
		      else
		      {
		    	  System.out.println("last Name Error message Failed");
		    	  // Positive last name
		          driver.findElement(By.name("lastname")).clear();
		          driver.findElement(By.name("lastname")).sendKeys("Mokka");
	    	  }
		  }

        
//    	7. Enter valid 'E-mail'.
        
        driver.findElement(By.id("input-email")).sendKeys("jabbar0596@gmail.com");
        
//    	8. Enter 'Telephone' which must be between 3 and 32 characters.
        driver.findElement(By.id("input-telephone")).sendKeys("9030418243");
        
//      9. Enter 'Password' which must be between 4 and 20 characters.
//     10. Enter 'Password Confirm'.       
        driver.findElement(By.name("password")).sendKeys("rajsubash");
        driver.findElement(By.id("input-confirm")).sendKeys("rajsubash");
        
        
        
        
//     11. Click on 'Yes' Radio button
        driver.findElement(By.name("newsletter")).click();

//     12. Click on checkbox for 'I have read and agree to the Privacy Policy'.
        driver.findElement(By.name("agree")).click();

//     13. Click on 'Continue' button
        driver.findElement(By.xpath("//input[@value='Continue']")).click();

        



        
//     14. Verify message 'Your Account Has Been Created!' 
        WebElement wb4 = driver.findElement(By.xpath("//*[@id='content']/h1"));
        String Accmessage = wb4.getText();
        String Vermessage ="Your Account Has Been Created!";

        if(Vermessage.equals(Accmessage))
        {
        	System.out.println("Account Message has verified Successfully");
        }
        else
        {
        	System.out.println("Account Message not verified");
        }

//     15. Click on 'Continue'
        driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();

        
//     16. Click on link 'View your order history' under 'My Orders'

        //Address
        driver.findElement(By.xpath("//*[@id='column-right']/div/a[4]")).click();
        driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();

        //FirstName add       
        driver.findElement(By.id("input-firstname")).sendKeys("Raj");

        //LastName add
        driver.findElement(By.id("input-lastname")).sendKeys("Raj");

        //CompanyName   add
        driver.findElement(By.id("input-company")).sendKeys("Capgemini");

        //Address
        driver.findElement(By.id("input-address-1")).sendKeys("52,Balasundaram street,Avarampalayam,Coimbatore");

        //City add
        driver.findElement(By.id("input-city")).sendKeys("Bangalore");

        //Post code add
        driver.findElement(By.id("input-postcode")).sendKeys("641006");

        //Country name
        WebElement wb11 = driver.findElement(By.id("input-country"));
        Select sel = new Select(wb11);
        sel.selectByValue("222");
        Thread.sleep(3000);

        //Region and Zone
        WebElement wb22 = driver.findElement(By.id("input-zone"));
        Select sel1 = new Select(wb22);
        sel1.selectByValue("3525");
        
        driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
        
        driver.close();	
	}
}


