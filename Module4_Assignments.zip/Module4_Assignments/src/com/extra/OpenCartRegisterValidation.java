package extra;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class OpenCartRegisterValidation {

	static String driverpath="C:\\Users\\jabmoham\\Documents\\zip files\\VnVATParticipantsMaterial\\VNV Software\\Selenium\\";
	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/index.php?route=account/register");
	    
 
        //FirstName verification
	    
	    driver.findElement(By.name("firstname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdeghi");
	    driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
	    WebElement wbt3 = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
        String txt5 = wbt3.getText();
        String text6 = "First Name must be between 1 and 32 characters!";
        if(text6.equals(txt5))
        {
        	System.out.println("First name error message verified");
        	
        }
        else
        {
        	System.out.println("First name not verified");
        }
	    
        // Positive First name
        driver.findElement(By.name("firstname")).clear();
        driver.findElement(By.name("firstname")).sendKeys("Raj");
        
        
        // LastName verification
        driver.findElement(By.name("lastname")).sendKeys("abcdeghijklmnopqrstuvwxyzabcdeghi");
	    driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
	    
	    WebElement wbt2 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
        String txt3 = wbt2.getText();
        
        String text4 = "Last Name must be between 1 and 32 characters!";
        if(text4.equals(txt3))
        {
        	System.out.println("Last name error message verified");
        	
        }
        else
        {
        	System.out.println("Last name not verified");
        }
		// Positive Last name
        driver.findElement(By.name("lastname")).clear();
        driver.findElement(By.name("lastname")).sendKeys("Subash");
        
        //Email and telephone
        driver.findElement(By.id("input-email")).sendKeys("jabbar3@gmail.com");
        driver.findElement(By.id("input-telephone")).sendKeys("04226541441");
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        
        //Password
        driver.findElement(By.name("password")).sendKeys("rajsubash");
        driver.findElement(By.id("input-confirm")).sendKeys("rajsubash");
        
        
        //Radio Button
        driver.findElement(By.name("newsletter")).click();
        //Privacy policy
        driver.findElement(By.name("agree")).click();
        
        driver.findElement(By.cssSelector("input[class='btn btn-primary']")).click();
        //Account message Verification 
        WebElement wb4 = driver.findElement(By.xpath("//*[@id='content']/h1"));
        String Accmessage = wb4.getText();
        String Vermessage ="Your Account Has Been Created!";
        if(Vermessage.equals(Accmessage))
        {
        	System.out.println("Account Message has verified Successfully");
        }
        else
        {
        	System.out.println("Account Message not verified");
        }
        //clicking Continue
        driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
      
        //Address
        driver.findElement(By.xpath("//*[@id='column-right']/div/a[4]")).click();
        driver.findElement(By.xpath("//*[@id='content']/div/div[2]/a")).click();
        //FirstName add       
        driver.findElement(By.id("input-firstname")).sendKeys("Raj");
        //LastName add
        driver.findElement(By.id("input-lastname")).sendKeys("Raj");
        //CompanyName   add
        driver.findElement(By.id("input-company")).sendKeys("Capgemini");
        //Address
        driver.findElement(By.id("input-address-1")).sendKeys("52,Balasundaram street,Avarampalayam,Coimbatore");
        //City add
        driver.findElement(By.id("input-city")).sendKeys("Bangalore");
        //Post code add
        driver.findElement(By.id("input-postcode")).sendKeys("641006");
        //Country name
        WebElement wb1 = driver.findElement(By.id("input-country"));
        Select sel = new Select(wb1);
        sel.selectByValue("222");
        Thread.sleep(3000);
        //Region and Zone
        WebElement wb2 = driver.findElement(By.id("input-zone"));
        Select sel1 = new Select(wb2);
        sel1.selectByValue("3525");
        
        driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
        
//        driver.close();	
	}

}
